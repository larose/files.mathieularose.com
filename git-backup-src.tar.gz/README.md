# `git-backup`

A a command-line tool that backs up your Git repositories to Amazon S3 or any S3-compatible storage.

## Website

https://mathieularose.com/git-backup
