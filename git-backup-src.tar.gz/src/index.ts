import { argv } from "process";
import { parseArgs } from "./parse-args";
import { snapshot } from "./snapshot";
import { prune } from "./prune";

export async function main() {
  const args = parseArgs(argv.slice(2));

  switch (args.type) {
    case "prune": {
      return prune(args);
    }

    case "snapshot": {
      return snapshot(args);
    }
  }
}
