import { DeleteObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { Remote } from "../parse-args";

export async function deleteSnapshots({
  snapshotKeysToDelete,
  s3Client,
  remote,
}: {
  snapshotKeysToDelete: Array<string>;
  s3Client: S3Client;
  remote: Remote;
}) {
  for (const snapshotKey of snapshotKeysToDelete) {
    console.log(`Deleting '${snapshotKey}' in bucket '${remote.bucket}'`);

    const command = new DeleteObjectCommand({
      Bucket: remote.bucket,
      Key: snapshotKey,
    });

    const response = await s3Client.send(command);
    if (response.$metadata.httpStatusCode !== 204) {
      console.error(response);
      throw new Error("Could not delete snapshot");
    }
  }
}
