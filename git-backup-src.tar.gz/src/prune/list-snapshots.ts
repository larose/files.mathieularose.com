import { ListObjectsV2Command, S3Client } from "@aws-sdk/client-s3";
import { GitRepo, Remote } from "../parse-args";
import { generateKey } from "../generate-key";

export async function listSnapshots({
  gitRepo,
  remote,
  s3Client,
}: {
  gitRepo: GitRepo;
  remote: Remote;
  s3Client: S3Client;
}) {
  let continuationToken: string | undefined;
  let hasMore = true;

  const snapshots: Array<string> = [];

  const prefix = generateKey({
    key: `${gitRepo.hyphenatedName}-`,
    keyPrefix: remote.keyPrefix,
  });

  console.log(
    `Listing snapshots starting with '${prefix}' in bucket '${remote.bucket}'`
  );

  while (hasMore) {
    const listObjectsCommand = new ListObjectsV2Command({
      Bucket: remote.bucket,
      Prefix: prefix,
      ContinuationToken: continuationToken,
    });

    const response = await s3Client.send(listObjectsCommand);

    if (response.$metadata.httpStatusCode !== 200) {
      console.error(response);
      throw new Error("Couldn't list objects");
    }

    if (response.Contents === undefined) {
      console.error(response);
      throw new Error("No Contents");
    }

    for (const content of response.Contents) {
      if (content.Key === undefined) {
        console.error(content);
        throw new Error("No key");
      }

      snapshots.push(content.Key);
    }

    continuationToken = response.ContinuationToken;
    hasMore = continuationToken !== undefined;
  }

  return snapshots;
}
