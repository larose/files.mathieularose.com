import _ from "lodash";
import { Snapshot } from "./types";
import { RetentionPolicy } from "../parse-args";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import isoWeek from "dayjs/plugin/isoWeek";
dayjs.extend(isoWeek);
dayjs.extend(utc);

type SnapshotGroupBy = (snapshot: Snapshot) => string;

export const RETENTION_POLICY_GROUP_BY: Record<string, SnapshotGroupBy> = {
  daily: (snapshot) =>
    `${snapshot.date.getUTCFullYear()}-${String(
      snapshot.date.getUTCMonth() + 1
    ).padStart(2, "0")}-${String(snapshot.date.getUTCDate()).padStart(2, "0")}`,
  weekly: (snapshot) => getYearWeek(snapshot.date),
  monthly: (snapshot) =>
    `${snapshot.date.getUTCFullYear()}-${String(
      snapshot.date.getUTCMonth() + 1
    ).padStart(2, "0")}`,
};

export function getYearWeek(date: Date): string {
  const parsedDate = dayjs.utc(date);

  return `${parsedDate.isoWeekYear()}-${String(parsedDate.isoWeek()).padStart(
    2,
    "0"
  )}`;
}

function snapshotKeysToKeepForGroup({
  snapshots,
  groupBy,
  numSnapshotsToKeep,
}: {
  snapshots: Array<Snapshot>;
  groupBy: SnapshotGroupBy;
  numSnapshotsToKeep: number;
}) {
  const snapshotKeysToKeep: Array<string> = [];

  const groupedSnapshots = _.groupBy(snapshots, groupBy);

  const sortedGroupNames = Object.keys(groupedSnapshots).sort().reverse();

  const snapshotGroupNamesToKeep = sortedGroupNames.slice(
    0,
    Math.min(sortedGroupNames.length, numSnapshotsToKeep)
  );

  snapshotGroupNamesToKeep.forEach((groupName) => {
    const snapshotToKeep = groupedSnapshots[groupName].sort().reverse()[0];

    snapshotKeysToKeep.push(snapshotToKeep.key);
  });

  return snapshotKeysToKeep;
}

export function computeSnapshotsToDelete({
  snapshots,
  retentionPolicy,
}: {
  snapshots: Array<Snapshot>;
  retentionPolicy: RetentionPolicy;
}): Array<string> {
  snapshots = snapshots
    .slice()
    .sort((a, b) => a.date.getTime() - b.date.getTime());

  const snapshotKeysToKeep = new Set<string>();

  for (const [frequency, numSnapshotsToKeep] of Object.entries(
    retentionPolicy
  )) {
    const groupBy = RETENTION_POLICY_GROUP_BY[frequency];

    const snapshotKeys = snapshotKeysToKeepForGroup({
      snapshots: snapshots,
      groupBy,
      numSnapshotsToKeep: numSnapshotsToKeep,
    });

    snapshotKeys.forEach((snapshotKey) => {
      snapshotKeysToKeep.add(snapshotKey);
    });
  }

  return _.difference(
    snapshots.map((snapshot) => snapshot.key),
    Array.from(snapshotKeysToKeep)
  ).sort();
}
