export interface Snapshot {
  key: string;
  date: Date;
}
