import { PruneArgs } from "../parse-args";
import { createS3Client } from "../s3";
import { listSnapshots } from "./list-snapshots";
import { computeSnapshotsToDelete } from "./snapshots-to-delete";
import { Snapshot } from "./types";
import _ from "lodash";
import { deleteSnapshots } from "./delete-snapshots";

function extractDateTimeFromFileName(fileName: string): Date | null {
  const regex = /(\d{8})T(\d{6})Z\.tar\.gz$/;
  const match = fileName.match(regex);

  if (match == null) {
    return null;
  }
  const year = parseInt(match[1].slice(0, 4), 10);
  const month = parseInt(match[1].slice(4, 6), 10) - 1; // Months are zero-based
  const day = parseInt(match[1].slice(6, 8), 10);
  const hours = parseInt(match[2].slice(0, 2), 10);
  const minutes = parseInt(match[2].slice(2, 4), 10);
  const seconds = parseInt(match[2].slice(4, 6), 10);

  return new Date(Date.UTC(year, month, day, hours, minutes, seconds));
}

function namesToSnapshot(snapshotNames: Array<string>) {
  return snapshotNames
    .map((snapshotName): Snapshot | undefined => {
      const date = extractDateTimeFromFileName(snapshotName);

      if (date === null) {
        return;
      }

      return { date, key: snapshotName };
    })
    .filter((snapshot): snapshot is Snapshot => snapshot !== undefined);
}

export async function prune({
  gitRepo,
  remote,
  remoteCredentials,
  retentionPolicy,
}: PruneArgs) {
  const s3Client = createS3Client({ remote, remoteCredentials });

  const snapshotNames = await listSnapshots({ gitRepo, s3Client, remote });

  const snapshots = namesToSnapshot(snapshotNames);

  const snapshotKeysToDelete = computeSnapshotsToDelete({
    snapshots: snapshots,
    retentionPolicy,
  });

  console.log(
    `Found ${snapshots.length} snapshots, deleting ${snapshotKeysToDelete.length} snapshots`
  );

  await deleteSnapshots({
    snapshotKeysToDelete: snapshotKeysToDelete,
    remote,
    s3Client,
  });
}
