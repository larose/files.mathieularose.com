import tape from "tape";
import {
  RETENTION_POLICY_GROUP_BY,
  computeSnapshotsToDelete,
  getYearWeek,
} from "./snapshots-to-delete";
import { Snapshot } from "./types";
import _ from "lodash";
import dayjs from "dayjs";
import weekOfYear from "dayjs/plugin/weekOfYear";
import utc from "dayjs/plugin/utc";
dayjs.extend(weekOfYear);
dayjs.extend(utc);

// April 2024
// Su Mo Tu We Th Fr Sa
//     1  2  3  4  5  6
//  7  8  9 10 11 12 13
// 14 15 16 17 18 19 20
// 21 22 23 24 25 26 27
// 28 29 30
//
// May 2024
// Su Mo Tu We Th Fr Sa
//           1  2  3  4
//  5  6  7  8  9 10 11
// 12 13 14 15 16 17 18
// 19 20 21 22 23 24 25
// 26 27 28 29 30 31

const snapshots: Array<Snapshot> = [
  { date: new Date(Date.UTC(2024, 1, 19)), key: "2024-02-19" },
  { date: new Date(Date.UTC(2024, 2, 19)), key: "2024-03-19" },
  { date: new Date(Date.UTC(2024, 3, 19)), key: "2024-04-19" },
  { date: new Date(Date.UTC(2024, 3, 20)), key: "2024-04-20" },
  { date: new Date(Date.UTC(2024, 4, 18)), key: "2024-05-18" },
  { date: new Date(Date.UTC(2024, 4, 19)), key: "2024-05-19" },
  { date: new Date(Date.UTC(2024, 4, 20)), key: "2024-05-20" },
  { date: new Date(Date.UTC(2024, 4, 21)), key: "2024-05-21" },
  { date: new Date(Date.UTC(2024, 4, 22)), key: "2024-05-22" },
  { date: new Date(Date.UTC(2024, 4, 23)), key: "2024-05-23" },
  { date: new Date(Date.UTC(2024, 4, 24)), key: "2024-05-24" },
  { date: new Date(Date.UTC(2024, 4, 25)), key: "2024-05-25" },
  { date: new Date(Date.UTC(2024, 4, 26)), key: "2024-05-26" },
  { date: new Date(Date.UTC(2024, 4, 26, 1)), key: "2024-05-26-01" },
  { date: new Date(Date.UTC(2024, 4, 26, 8)), key: "2024-05-26-08" },
  { date: new Date(Date.UTC(2024, 4, 26, 16)), key: "2024-05-26-16" },
  { date: new Date(Date.UTC(2024, 4, 26, 23)), key: "2024-05-26-23" },
  // 2024-05-27 is skipped
  { date: new Date(Date.UTC(2024, 4, 28)), key: "2024-05-28" },
];

function shuffle<T>(array: Array<T>) {
  return array.slice().sort(() => Math.random() - 0.5);
}

tape("computeSnapshotsToDelete", (test) => {
  test.deepEqual(
    computeSnapshotsToDelete({
      snapshots: shuffle(snapshots),
      retentionPolicy: {
        daily: 4,
        monthly: 3,
        weekly: 3,
      },
    }),
    [
      "2024-02-19",
      "2024-04-19",
      "2024-05-18",
      "2024-05-20",
      "2024-05-21",
      "2024-05-22",
      "2024-05-23",
      "2024-05-26",
      "2024-05-26-01",
      "2024-05-26-08",
      "2024-05-26-16",
    ]
  );

  test.end();
});

tape("Retention policy group by", (test) => {
  const snapshot: Snapshot = {
    date: new Date(Date.UTC(2024, 1, 19)),
    key: "2024-02-19",
  };
  test.equal(RETENTION_POLICY_GROUP_BY.daily(snapshot), "2024-02-19");
  test.equal(RETENTION_POLICY_GROUP_BY.monthly(snapshot), "2024-02");
  test.equal(RETENTION_POLICY_GROUP_BY.weekly(snapshot), "2024-08");

  test.end();
});

tape("getYearWeek", (test) => {
  test.equal(getYearWeek(new Date(Date.UTC(2024, 1, 3))), "2024-05");
  test.equal(getYearWeek(new Date(Date.UTC(2024, 4, 26))), "2024-21");
  test.equal(getYearWeek(new Date(Date.UTC(2024, 4, 26, 23))), "2024-21");
  test.equal(getYearWeek(new Date(Date.UTC(2024, 4, 27))), "2024-22");
  test.equal(getYearWeek(new Date(Date.UTC(2024, 4, 27, 1))), "2024-22");
  test.equal(getYearWeek(new Date(Date.UTC(2024, 4, 27, 8))), "2024-22");

  test.end();
});
