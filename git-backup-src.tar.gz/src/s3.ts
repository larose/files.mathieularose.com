import { S3Client } from "@aws-sdk/client-s3";
import { Remote, RemoteCredentials } from "./parse-args";

export function createS3Client({
  remote,
  remoteCredentials,
}: {
  remote: Remote;
  remoteCredentials: RemoteCredentials;
}) {
  return new S3Client({
    credentials: {
      accessKeyId: remoteCredentials.accessKeyId,
      secretAccessKey: remoteCredentials.secretAccessKey,
    },
    endpoint: remote.endpoint,
    region: remote.region,
  });
}
