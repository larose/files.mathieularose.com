import tape from "tape";
import { parseRemote, parseRetentionPolicy } from "./parse-args";

tape("parseRetentionPolicy", (test) => {
  test.throws(() => {
    test.deepEqual(parseRetentionPolicy(""), {
      daily: 0,
      monthly: 3,
      weekly: 2,
    });
  }, new Error("Invalid sub-policy '': expected two parts."));

  test.deepEqual(parseRetentionPolicy("daily=1, weekly=2, monthly=3"), {
    daily: 1,
    monthly: 3,
    weekly: 2,
  });

  test.deepEqual(parseRetentionPolicy("weekly=2, monthly=3"), {
    daily: 0,
    monthly: 3,
    weekly: 2,
  });

  test.end();
});

tape("parseRemote", (test) => {
  test.deepEqual(
    parseRemote("https://160ddb3e.r2.cloudflarestorage.com/62dcf4d8"),
    {
      bucket: "62dcf4d8",
      endpoint: "https://160ddb3e.r2.cloudflarestorage.com",
      keyPrefix: "",
      region: "auto",
    }
  );

  test.end();
});
