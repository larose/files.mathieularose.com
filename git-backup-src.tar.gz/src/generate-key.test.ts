import tape from "tape";
import { generateKey } from "./generate-key";

tape("generateKey", (test) => {
  test.deepEqual(generateKey({ key: "foo", keyPrefix: "" }), "foo");

  test.deepEqual(
    generateKey({ key: "foo", keyPrefix: "base/path" }),
    "base/path/foo"
  );

  test.end();
});
