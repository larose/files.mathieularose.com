import * as tar from "tar";
import path from "node:path";

export async function createSnapshot({
  sourceFilePath,
  destinationFilePath,
}: {
  sourceFilePath: string;
  destinationFilePath: string;
}): Promise<void> {
  const sourceFileName = path.basename(sourceFilePath);
  const cwd = path.dirname(sourceFilePath);

  await tar.c(
    {
      gzip: true,
      file: destinationFilePath,
      cwd,
    },
    [sourceFileName]
  );
}
