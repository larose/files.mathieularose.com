import { spawn } from "child_process";

export async function cloneRepo({
  repoUrl,
  targetPath,
}: {
  repoUrl: string;
  targetPath: string;
}): Promise<void> {
  return new Promise((resolve, reject) => {
    console.log(`Cloning repository from '${repoUrl}' to '${targetPath}'`);

    const gitProcess = spawn("git", [
      "clone",
      "--mirror",
      "--quiet",
      repoUrl,
      targetPath,
    ]);

    gitProcess.stdout.on("data", (data: Buffer) => {
      console.log(data.toString("utf-8"));
    });

    gitProcess.stderr.on("data", (data: Buffer) => {
      console.error(data.toString("utf-8"));
    });

    gitProcess.on("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Git process exited with code ${code}`));
      }
    });

    gitProcess.on("error", (error) => {
      reject(new Error(`Failed to start git clone: ${error.message}`));
    });
  });
}
