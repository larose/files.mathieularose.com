import { tmpdir } from "node:os";
import fs from "node:fs/promises";
import { cloneRepo } from "./clone-repo";
import { createSnapshot } from "./create-snapshot";
import { uploadSnapshot } from "./upload-snapshot";
import { GitRepo, SnapshotArgs } from "../parse-args";
import path from "node:path";

interface Info {
  gitRepoDirectory: string;
  snapshotFilePath: string;
}

function createInfo({
  gitRepo,
  tempDirectory,
}: {
  gitRepo: GitRepo;
  tempDirectory: string;
}): Info {
  const gitRepoDirectory = path.join(tempDirectory, gitRepo.hyphenatedName);

  const timeSuffix = getCurrentTimestamp();

  const snapshotFileName = `${gitRepo.hyphenatedName}-${timeSuffix}.tar.gz`;

  const snapshotFilePath = path.join(tempDirectory, snapshotFileName);

  return { gitRepoDirectory, snapshotFilePath };
}

function getCurrentTimestamp(): string {
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, "0");
  const day = String(now.getUTCDate()).padStart(2, "0");
  const hours = String(now.getUTCHours()).padStart(2, "0");
  const minutes = String(now.getUTCMinutes()).padStart(2, "0");
  const seconds = String(now.getUTCSeconds()).padStart(2, "0");

  return `${year}${month}${day}T${hours}${minutes}${seconds}Z`;
}

export async function snapshot({
  gitRepo,
  remote,
  remoteCredentials,
}: SnapshotArgs) {
  const tempDirectory = await fs.mkdtemp(path.join(tmpdir(), "git-backup-"));

  const { gitRepoDirectory, snapshotFilePath } = createInfo({
    gitRepo,
    tempDirectory,
  });

  await cloneRepo({ repoUrl: gitRepo.url, targetPath: gitRepoDirectory });

  await createSnapshot({
    sourceFilePath: gitRepoDirectory,
    destinationFilePath: snapshotFilePath,
  });

  await uploadSnapshot({
    snapshotFilePath: snapshotFilePath,
    remote,
    remoteCredentials,
  });
}
