import { PutObjectCommand } from "@aws-sdk/client-s3";
import fs from "node:fs/promises";
import { Remote, RemoteCredentials } from "../parse-args";
import { basename } from "node:path";
import { createS3Client } from "../s3";
import { generateKey } from "../generate-key";

export async function uploadSnapshot({
  remote,
  remoteCredentials,
  snapshotFilePath,
}: {
  remote: Remote;
  remoteCredentials: RemoteCredentials;
  snapshotFilePath: string;
}) {
  const snapshotStream = (await fs.open(snapshotFilePath)).createReadStream({
    autoClose: true,
  });

  const basenameKey = basename(snapshotFilePath);
  const key = generateKey({ key: basenameKey, keyPrefix: remote.keyPrefix });

  const putObjectCommand = new PutObjectCommand({
    Bucket: remote.bucket,
    Key: key,
    Body: snapshotStream,
  });

  console.log(`Uploading snapshot to '${key}'`);

  const s3Client = createS3Client({ remote, remoteCredentials });

  const response = await s3Client.send(putObjectCommand);

  if (response.$metadata.httpStatusCode !== 200) {
    console.error(response);
    throw new Error("Couldn't upload snapshot");
  }
}
