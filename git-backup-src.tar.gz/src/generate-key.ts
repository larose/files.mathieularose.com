export function generateKey({
  key,
  keyPrefix,
}: {
  key: string;
  keyPrefix: string;
}) {
  if (keyPrefix === "") {
    return key;
  }

  return [keyPrefix, key].join("/");
}
