import gitUrlParse from "git-url-parse";
import { parseArgs as _parseArgs } from "node:util";

const pruneOptions = {
  "access-key-id": {
    type: "string",
  },
  remote: {
    type: "string",
  },
  repo: {
    type: "string",
  },
  "retention-policy": {
    type: "string",
  },
  "secret-access-key": { type: "string" },
} as const;

const snapshotOptions = {
  "access-key-id": {
    type: "string",
  },
  remote: {
    type: "string",
  },
  repo: {
    type: "string",
  },
  "secret-access-key": { type: "string" },
} as const;

export interface GitRepo {
  hyphenatedName: string;
  url: string;
}

export interface RetentionPolicy extends Record<string, number> {
  daily: number;
  weekly: number;
  monthly: number;
}

export interface PruneArgs {
  type: "prune";
  gitRepo: GitRepo;
  remote: Remote;
  remoteCredentials: RemoteCredentials;
  retentionPolicy: RetentionPolicy;
}

export interface SnapshotArgs {
  type: "snapshot";
  gitRepo: GitRepo;
  remote: Remote;
  remoteCredentials: RemoteCredentials;
}

type Args = PruneArgs | SnapshotArgs;

export interface RemoteCredentials {
  accessKeyId: string;
  secretAccessKey: string;
}

export interface Remote {
  bucket: string;
  endpoint: string;
  keyPrefix: string;
  region: string;
}

export function parseRemote(remote: string): Remote {
  const { hostname, origin, pathname } = new URL(remote);

  let region = "auto";

  const hostnameParts = hostname.split(".");
  if (hostnameParts.includes("amazonaws")) {
    if (hostnameParts.length === 4) {
      region = hostnameParts[1];
    } else {
      region = "us-east-1";
    }
  }

  const pathnameParts = pathname.split("/");

  if (pathnameParts.length < 2) {
    throw new Error("No bucket");
  }
  const bucket = pathnameParts[1];

  const keyPrefix =
    pathnameParts.length > 2 ? pathnameParts.slice(2).join("/") : "";

  return {
    bucket,
    endpoint: origin,
    keyPrefix,
    region,
  };
}

const DEFAULT_RETENTION_POLICY: RetentionPolicy = {
  daily: 7,
  monthly: 3,
  weekly: 5,
};

export function parseRetentionPolicy(retentionPolicy: string): RetentionPolicy {
  const policy: RetentionPolicy = {
    daily: 0,
    monthly: 0,
    weekly: 0,
  };

  retentionPolicy.split(",").forEach((subPolicy) => {
    const parts = subPolicy.split("=").map((part) => part.trim());
    if (parts.length !== 2) {
      throw Error(
        `Invalid sub-policy '${subPolicy.trim()}': expected two parts.`
      );
    }

    const frequencyName = parts[0];
    const keep = parseInt(parts[1], 10);
    if (!isFinite(keep) || keep < 0) {
      throw Error(
        `Invalid sub-policy '${subPolicy.trim()}': expected a non-negative integer`
      );
    }

    switch (frequencyName) {
      case "daily": {
        policy.daily = keep;
        break;
      }

      case "monthly": {
        policy.monthly = keep;
        break;
      }

      case "weekly": {
        policy.weekly = keep;
        break;
      }

      default: {
        throw Error(
          `Invalid sub-policy '${subPolicy.trim()}': expected daily, monthly or weekly`
        );
      }
    }
  });

  return policy;
}

export function parseArgs(args: Array<string>): Args {
  const { positionals } = _parseArgs({ args, strict: false });

  if (positionals.length === 0) {
    throw Error("No command");
  }

  const command = positionals[0];

  if (command === "prune") {
    const {
      values: {
        "access-key-id": accessKeyId,
        remote,
        repo,
        "retention-policy": retentionPolicy,
        "secret-access-key": secretAccessKey,
      },
    } = _parseArgs({
      allowPositionals: true,
      args,
      options: pruneOptions,
      strict: true,
    });

    if (repo === undefined) {
      throw new Error("--repo is not defined");
    }

    if (remote === undefined) {
      throw new Error("--remote is not defined");
    }

    if (accessKeyId === undefined) {
      throw new Error("--access-key-id is not defined");
    }

    if (secretAccessKey === undefined) {
      throw new Error("--secret-access-key is not defined");
    }

    return {
      type: "prune",
      gitRepo: {
        hyphenatedName: generateHyphenatedRepoName(repo),
        url: repo,
      },
      remote: parseRemote(remote),
      remoteCredentials: {
        accessKeyId,
        secretAccessKey,
      },
      retentionPolicy:
        retentionPolicy !== undefined
          ? parseRetentionPolicy(retentionPolicy)
          : DEFAULT_RETENTION_POLICY,
    };
  }

  if (command === "snapshot") {
    const {
      values: {
        "access-key-id": accessKeyId,
        remote,
        repo,
        "secret-access-key": secretAccessKey,
      },
    } = _parseArgs({
      allowPositionals: true,
      args,
      options: snapshotOptions,
      strict: true,
    });

    if (repo === undefined) {
      throw new Error("--repo is not defined");
    }

    if (remote === undefined) {
      throw new Error("--remote is not defined");
    }

    if (accessKeyId === undefined) {
      throw new Error("--access-key-id is not defined");
    }

    if (secretAccessKey === undefined) {
      throw new Error("--secret-access-key is not defined");
    }

    const hyphenatedRepoFullName = generateHyphenatedRepoName(repo);

    return {
      type: "snapshot",
      remote: parseRemote(remote),
      remoteCredentials: {
        accessKeyId,
        secretAccessKey,
      },
      gitRepo: { hyphenatedName: hyphenatedRepoFullName, url: repo },
    };
  }

  throw Error(`Unknown command ${command}`);
}
function generateHyphenatedRepoName(repo: string) {
  const { full_name: repoFullName } = gitUrlParse(repo);
  const hyphenatedRepoFullName = repoFullName.replace(/\//g, "-");
  return hyphenatedRepoFullName;
}
