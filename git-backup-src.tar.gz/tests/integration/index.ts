import { spawn, spawnSync } from "child_process";
import path from "path";
import process from "node:process";
import { tmpdir } from "node:os";
import fs from "node:fs/promises";
import { S3Client, ListObjectsV2Command } from "@aws-sdk/client-s3";

const ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE";
const SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";
const S3_SERVER_PORT = 9000;

async function installGitBackup({
  cwd,
  packagePath,
}: {
  cwd: string;
  packagePath: string;
}) {
  console.log("Installing git-backup");

  {
    const { status } = spawnSync("npm", ["install", packagePath], {
      cwd,
      stdio: "inherit",
    });

    if (status !== 0) {
      throw new Error("Couldn't install git-backup");
    }
  }
}

async function runSnapshotHappyPath({ cwd }: { cwd: string }) {
  console.log("Running git-backup");

  const numSnapshots = 3;

  const bucket = "git-backup-64df2742";
  const path = "larose/utt";

  for (let i = 0; i < numSnapshots; i++) {
    const { status } = spawnSync(
      "npx",
      [
        "git-backup",
        "snapshot",
        "--repo",
        "git@github.com:larose/utt.git",
        "--remote",
        `http://127.0.0.1:9000/${bucket}/${path}`,
        "--access-key-id",
        ACCESS_KEY_ID,
        "--secret-access-key",
        SECRET_ACCESS_KEY,
      ],
      {
        cwd,
        stdio: "inherit",
      }
    );

    if (status !== 0) {
      throw new Error("git-backup snapshot failed");
    }
  }

  const s3Client = new S3Client({
    credentials: {
      accessKeyId: ACCESS_KEY_ID,
      secretAccessKey: SECRET_ACCESS_KEY,
    },
    endpoint: `http://127.0.0.1:${S3_SERVER_PORT}`,
    region: "auto",
  });

  const listObjectsCommand = new ListObjectsV2Command({
    Bucket: bucket,
    Prefix: path,
  });

  const response = await s3Client.send(listObjectsCommand);

  if (response.Contents === undefined) {
    throw new Error("No Contents");
  }

  if (response.Contents.length !== numSnapshots) {
    throw new Error(
      `There are ${response.Contents.length} snapshots, expected ${numSnapshots}`
    );
  }

  {
    const { status } = spawnSync(
      "npx",
      [
        "git-backup",
        "prune",
        "--repo",
        "git@github.com:larose/utt.git",
        "--remote",
        `http://127.0.0.1:9000/${bucket}/${path}`,
        "--retention-policy",
        "daily=1, monthly=5, weekly=5",
        "--access-key-id",
        ACCESS_KEY_ID,
        "--secret-access-key",
        SECRET_ACCESS_KEY,
      ],
      {
        cwd,
        stdio: "inherit",
      }
    );

    if (status !== 0) {
      throw new Error("git-backup prune failed");
    }
  }

  {
    const listObjectsCommand = new ListObjectsV2Command({
      Bucket: bucket,
      Prefix: path,
    });

    const response = await s3Client.send(listObjectsCommand);

    if (response.Contents === undefined) {
      throw new Error("No Contents");
    }

    if (response.Contents.length !== 1) {
      throw new Error(
        `There are ${response.Contents.length} snapshots, expected ${numSnapshots}`
      );
    }
  }
}

async function startS3Server() {
  console.log("Starting s3 server");

  const s3Server = spawn(
    "docker",
    `run --rm --interactive --publish ${S3_SERVER_PORT}:${S3_SERVER_PORT} scireum/s3-ninja:8.3.3`.split(
      " "
    )
  );

  process.on("exit", () => {
    s3Server.kill();
  });

  return new Promise<{
    stop: () => void;
  }>((resolve) => {
    s3Server.stdout.on("data", (data: Buffer) => {
      const text = data.toString("utf-8").trimEnd();
      console.log(text);

      if (text.includes("System is UP and RUNNING")) {
        resolve({
          stop: () => {
            console.log("Stopping s3 server");
            s3Server.kill();
          },
        });
      }
    });

    s3Server.stderr.on("data", (data: Buffer) => {
      console.error(data.toString("utf-8"));
    });
  });
}

async function main() {
  const tempDirectory = await fs.mkdtemp(
    path.join(tmpdir(), "git-backup-test-")
  );

  console.log(`Running tests in ${tempDirectory}`);

  const packagePath = path.join(process.cwd(), "package.tgz");

  const { stop: stopS3Server } = await startS3Server();

  try {
    await installGitBackup({ cwd: tempDirectory, packagePath });
    await runSnapshotHappyPath({ cwd: tempDirectory });
  } finally {
    stopS3Server();
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error(error);
  });
}
